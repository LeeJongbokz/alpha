import "react-native-gesture-handler";
import App from "./app/index";
export default App;