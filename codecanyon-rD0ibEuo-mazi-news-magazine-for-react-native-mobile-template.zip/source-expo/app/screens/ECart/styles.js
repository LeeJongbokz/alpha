import { StyleSheet } from "react-native";
import { BaseColor } from "@config";

export default StyleSheet.create({
    header: {
        paddingHorizontal: 20,
        marginBottom: 16,
    },
});
