import { BaseColor } from "@config";
import { StyleSheet } from "react-native";

export default StyleSheet.create({
    content: {
        width: "100%",
        height: 10,
        position: "relative",
    },
    container: {
        height: 10
    }
});
