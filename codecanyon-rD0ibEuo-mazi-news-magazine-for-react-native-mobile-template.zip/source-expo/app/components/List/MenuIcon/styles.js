import React from "react";
import { StyleSheet } from "react-native";

export default StyleSheet.create({
    contain: {
        flexDirection: "row",
        paddingVertical: 10,
        borderBottomWidth: 1,
    },
});
