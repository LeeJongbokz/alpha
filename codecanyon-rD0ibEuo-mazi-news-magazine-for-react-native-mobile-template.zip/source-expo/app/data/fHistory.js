import { BaseColor } from "@config";
import { Images } from "@config";

export const FHistory = [
  {
    id: "1",
    title : "Feb 21 2021",
    textLeft : "Money Sent",
    textRight : "-$1,210.00",
  },
  {
    id: "2",
    title : "Feb 21 2021",
    textLeft : "Money Sent",
    textRight : "-$1,210.00",
  },
  {
    id: "3",
    title : "Feb 21 2021",
    textLeft : "Money Sent",
    textRight : "-$1,210.00",
  },
  {
    id: "4",
    title : "Feb 21 2021",
    textLeft : "Money Sent",
    textRight : "-$1,210.00",
  },
  {
    id: "5",
    title : "Feb 21 2021",
    textLeft : "Money Sent",
    textRight : "-$1,210.00",
  },
  {
    id: "6",
    title : "Feb 21 2021",
    textLeft : "Money Sent",
    textRight : "-$1,210.00",
  },
  {
    id: "7",
    title : "Feb 21 2021",
    textLeft : "Money Sent",
    textRight : "-$1,210.00",
  },
  {
    id: "8",
    title : "Feb 21 2021",
    textLeft : "Money Sent",
    textRight : "-$1,210.00",
  },
];
