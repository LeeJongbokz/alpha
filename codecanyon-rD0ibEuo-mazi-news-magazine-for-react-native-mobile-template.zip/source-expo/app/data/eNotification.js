import { Images } from "@config";

export const ENotificationData = [
  {
    id: 1,
    image: Images.notificationIcon,
    txtLeftTitle: "Lorem ipsum dolor sit",
    txtContent: "At vero eos et accusam et justo duo dolores …",
    txtRight: "Dec 11, 2018",
  },
  {
    id: 2,
    image: Images.notificationIcon,
    txtLeftTitle: "Lorem ipsum dolor sit",
    txtContent: "At vero eos et accusam et justo duo dolores …",
    txtRight: "Dec 11, 2018",
  },
  {
    id: 3,
    image: Images.notificationIcon,
    txtLeftTitle: "Lorem ipsum dolor sit",
    txtContent: "At vero eos et accusam et justo duo dolores …",
    txtRight: "Dec 11, 2018",
  },
  {
    id: 4,
    image: Images.notificationIcon,
    txtLeftTitle: "Lorem ipsum dolor sit",
    txtContent: "At vero eos et accusam et justo duo dolores …",
    txtRight: "Dec 11, 2018",
  },
  {
    id: 5,
    image: Images.notificationIcon,
    txtLeftTitle: "Lorem ipsum dolor sit",
    txtContent: "At vero eos et accusam et justo duo dolores …",
    txtRight: "Dec 11, 2018",
  },
  {
    id: 6,
    image: Images.notificationIcon,
    txtLeftTitle: "Lorem ipsum dolor sit",
    txtContent: "At vero eos et accusam et justo duo dolores …",
    txtRight: "Dec 11, 2018",
  },
  {
    id: 7,
    image: Images.notificationIcon,
    txtLeftTitle: "Lorem ipsum dolor sit",
    txtContent: "At vero eos et accusam et justo duo dolores …",
    txtRight: "Dec 11, 2018",
  },
  {
    id: 8,
    image: Images.notificationIcon,
    txtLeftTitle: "Lorem ipsum dolor sit",
    txtContent: "At vero eos et accusam et justo duo dolores …",
    txtRight: "Dec 11, 2018",
  },
  {
    id: 9,
    image: Images.notificationIcon,
    txtLeftTitle: "Lorem ipsum dolor sit",
    txtContent: "At vero eos et accusam et justo duo dolores …",
    txtRight: "Dec 11, 2018",
  },
];
