import { Images } from "@config";

const NotificationData = [
  {
    id: "0",
    title: "Obasey Chidy",
    description: "Its time to build a difference ...",
    image: Images.avata1,
    date: "Dec 11, 2018",
  },
  {
    id: "1",
    title: "Steve Garrett",
    description: "Its time to build a difference ...",
    image: Images.avata2,
    date: "Dec 11, 2018",
  },
  {
    id: "2",
    title: "Luvleen Lawrence",
    description: "Its time to build a difference ...",
    image: Images.avata3,
    date: "Dec 11, 2018",
  },
  {
    id: "3",
    title: "Tom Hardy",
    description: "Its time to build a difference ...",
    image: Images.avata4,
    date: "Dec 11, 2019",
  },
];

export { NotificationData };
