import { Images } from "@config";

export const OrderDetail = {
  id: "#39072197",
  items: [],
  total: "$154.00",
  placedOn: "28 Apr 2020 09:00",
  paidOn: "01 May 2020 18:00",
  status: "Shipping",
};
