import { Images } from "@config";
export const AboutUsData = [
  {
    id: "1",
    screen: "Profile1",
    image: Images.profile2,
    subName: "CEO Founder",
    name: "Kondo Ieyasu",
    description:
      "Lorem ipsum dolor sit amet, sed do eiusmod tempor incididunt ut labore",
  },
  {
    id: "2",
    screen: "Profile2",
    image: Images.profile3,
    subName: "Sale Manager",
    name: "Yeray Rosales",
    description:
      "Lorem ipsum dolor sit amet, sed do eiusmod tempor incididunt ut labore",
  },
  {
    id: "3",
    screen: "Profile3",
    image: Images.profile5,
    subName: "Product Manager",
    name: "Alf Huncoot",
    description:
      "Lorem ipsum dolor sit amet, sed do eiusmod tempor incididunt ut labore",
  },
  {
    id: "4",
    screen: "Profile4",
    image: Images.profile4,
    subName: "Designer UI/UX",
    name: "Chioke Okonkwo",
    description:
      "Lorem ipsum dolor sit amet, sed do eiusmod tempor incididunt ut labore",
  },
];
