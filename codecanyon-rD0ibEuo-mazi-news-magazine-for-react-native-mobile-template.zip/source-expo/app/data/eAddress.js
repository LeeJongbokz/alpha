export const EAddressData = [
  {
    id: 1,
    name: "Steve Garrett",
    address:
      "35 Mandalay Road # 13–37 Mandalay Towers Singapore 308215 SINGAPORE",
    phone: "+65 1290 1234",
  },
  {
    id: 2,
    name: "Steve Garrett",
    address:
      "35 Mandalay Road # 13–37 Mandalay Towers Singapore 308215 SINGAPORE",
    phone: "+65 1290 1234",
  },
  {
    id: 3,
    name: "Steve Garrett",
    address:
      "35 Mandalay Road # 13–37 Mandalay Towers Singapore 308215 SINGAPORE",
    phone: "+65 1290 1234",
  },
  {
    id: 4,
    name: "Steve Garrett",
    address:
      "35 Mandalay Road # 13–37 Mandalay Towers Singapore 308215 SINGAPORE",
    phone: "+65 1290 1234",
  },
  {
    id: 5,
    name: "Steve Garrett",
    address:
      "35 Mandalay Road # 13–37 Mandalay Towers Singapore 308215 SINGAPORE",
    phone: "+65 1290 1234",
  },
  {
    id: 6,
    name: "Steve Garrett",
    address:
      "35 Mandalay Road # 13–37 Mandalay Towers Singapore 308215 SINGAPORE",
    phone: "+65 1290 1234",
  },
  {
    id: 7,
    name: "Steve Garrett",
    address:
      "35 Mandalay Road # 13–37 Mandalay Towers Singapore 308215 SINGAPORE",
    phone: "+65 1290 1234",
  },
  {
    id: 8,
    name: "Steve Garrett",
    address:
      "35 Mandalay Road # 13–37 Mandalay Towers Singapore 308215 SINGAPORE",
    phone: "+65 1290 1234",
  },
];
