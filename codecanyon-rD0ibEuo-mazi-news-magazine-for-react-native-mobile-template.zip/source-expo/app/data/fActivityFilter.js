export const FPayment = [
    {
        id: 1,
        title: "All Transaction",
    },
    {
        id: 2,
        title: "Payment Recived",
    },
    {
        id: 3,
        title: "Payment Send",
    },
];

export const FPeriod = [
    {
        id: 1,
        title: "All Transaction",
    },
    {
        id: 2,
        title: "Pass 90 Days",
    },
    {
        id: 3,
        title: "Pass 30 Days",
    },
    {
        id: 4,
        title: "Pass A Week",
    },
];
