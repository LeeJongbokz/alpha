export const EPaymentItemsData = [
    {
        id: "**** **** **** 1989",
        expiryDate: "Expiries 02/2020",
        iconName: "credit-card",
    },
    {
        id: "**** **** **** 1990",
        expiryDate: "Expiries 03/2020",
        iconName: "paypal",
    },
    {
        id: "**** **** **** 1991",
        expiryDate: "Expiries 04/2020",
        iconName: "cc-mastercard",
    },
];
