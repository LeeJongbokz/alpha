export const FPaymentItemsData = [
    {
        id: "**** **** **** 1989",
        expiryDate: "Expiries 02/2020",
        iconName: "credit-card",
    },
    {
        id: "steve.garrett@passionui.com",
        expiryDate: "Added 01/2019",
        iconName: "paypal",
    },
    {
        id: "**** **** **** 2091",
        expiryDate: "Expiries 10/2021",
        iconName: "cc-mastercard",
    },
    {
        id: "steve.garrett@icloud.com",
        expiryDate: "Expiries 01/2019",
        iconName: "apple-pay",
    },
];
  